Stellar Theme v3.3 — Updated for Pterodactyl 1.11.x compatibility
==================================================================

WHAT CHANGED IN THIS UPDATE
-----------------------------
1. ServerTransformer.php
   - Fixed: oom_disabled -> oom_killer_disabled (renamed in Pterodactyl 1.11+)
   - Backward compatible via null-coalescing fallback

2. getServer.ts
   - Fixed: limits interface now includes oomKillerDisabled: boolean
   - Fixed: rawDataToServerObject maps oom_killer_disabled correctly

3. getThemeData.ts
   - Added: try/catch error handling (panel no longer crashes if theme API fails)
   - Fixed: return type is now Promise<Record<string, string>>

4. DashboardContainer.tsx
   - Fixed: infinite loading spinner when themeData not yet loaded (null → spinner, unknown value → fallback to cards)
   - Fixed: themeData state typed as string | null instead of any

5. tailwind.config.js
   - Fixed: @tailwindcss/line-clamp plugin commented out (built-in since Tailwind v3.3, causes duplicate warning)

6. wrapper.blade.php
   - Fixed: null-safe check around $settings DB query (prevents crash if 'theme' table not yet migrated)
   - Fixed: favicon and meta tags also null-safe
   - Removed: 3rd-party license tracking script (localStorage injection)

7. ClientController.php
   - Fixed: theme() method wrapped in try/catch (safe if theme table doesn't exist yet)

8. Migrations
   - Fixed: both migrations now guard against re-running (hasTable/hasColumn checks)

INSTALLATION STEPS (Pterodactyl 1.11+)
----------------------------------------
1. Make sure build dependencies are installed:
   https://pterodactyl.io/community/customization/panel.html

2. Copy files to /var/www/pterodactyl — only REPLACE existing files, do NOT delete anything

3. Run commands:
   cd /var/www/pterodactyl
   yarn add react-feather
   php artisan migrate
   > yes
   yarn build:production
   php artisan view:clear
   php artisan cache:clear

4. Configure theme in Admin Panel > Settings > Theme

KNOWN COMPATIBILITY
--------------------
- Pterodactyl 1.11.x: SUPPORTED (this update)
- Pterodactyl 1.10.x: SUPPORTED (original)
- Pterodactyl 1.9.x and below: Untested

For support: https://discord.gg/geCjrRbAwC
