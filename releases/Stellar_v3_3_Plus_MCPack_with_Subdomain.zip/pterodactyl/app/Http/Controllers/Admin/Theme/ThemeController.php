<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class ThemeController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        try {
            $theme = DB::table('theme')->first();
        } catch (\Exception $e) {
            $theme = null;
        }

        return view('admin.theme.index', ['theme' => $theme]);
    }

    public function update(Request $request)
    {
        $request->validate([
            'logo'            => 'nullable|string|max:500',
            'longlogo'        => 'nullable|string|max:500',
            'backgroundimage' => 'nullable|string|max:500',
        ]);

        try {
            $existing = DB::table('theme')->first();
            if ($existing) {
                DB::table('theme')->where('id', $existing->id)->update([
                    'logo'            => $request->logo ?? $existing->logo,
                    'longlogo'        => $request->longlogo ?? $existing->longlogo,
                    'backgroundimage' => $request->backgroundimage ?? $existing->backgroundimage,
                    'updated_at'      => \Carbon\Carbon::now(),
                ]);
            }
        } catch (\Exception $e) {
            $this->alert->danger('Failed to update theme settings: ' . $e->getMessage())->flash();
            return redirect()->back();
        }

        $this->alert->success('Theme settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
