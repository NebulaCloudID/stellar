<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class ElementController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        try {
            $theme = DB::table('theme')->first();
        } catch (\Exception $e) {
            $theme = null;
        }

        return view('admin.theme.element', ['theme' => $theme]);
    }

    public function update(Request $request)
    {
        $request->validate([
            'subnavigation' => 'required|in:0,1',
            'graphcard'     => 'required|in:0,1',
            'sidegraph'     => 'required|in:0,1',
            'infoelement'   => 'required|in:0,1',
            'newserverlist' => 'required|in:table,cards,list',
        ]);

        try {
            $existing = DB::table('theme')->first();
            if ($existing) {
                DB::table('theme')->where('id', $existing->id)->update([
                    'subnavigation' => (int) $request->subnavigation,
                    'graphcard'     => (int) $request->graphcard,
                    'sidegraph'     => (int) $request->sidegraph,
                    'infoelement'   => (int) $request->infoelement,
                    'newserverlist' => $request->newserverlist,
                    'updated_at'    => \Carbon\Carbon::now(),
                ]);
            }
        } catch (\Exception $e) {
            $this->alert->danger('Failed to update element settings: ' . $e->getMessage())->flash();
            return redirect()->back();
        }

        $this->alert->success('Element settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
