<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class ButtonController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        try {
            $theme = DB::table('theme')->first();
        } catch (\Exception $e) {
            $theme = null;
        }

        return view('admin.theme.button', ['theme' => $theme]);
    }

    public function update(Request $request)
    {
        $colorRule    = 'nullable|regex:/^#[0-9A-Fa-f]{3,8}$/';
        $radiusRule   = 'nullable|integer|min:0|max:50';

        $request->validate([
            'textbutton'        => $colorRule,
            'textbuttonhover'   => $colorRule,
            'dangerbutton'      => $colorRule,
            'dangerbuttonhover' => $colorRule,
            'ltextbutton'       => $colorRule,
            'ltextbuttonhover'  => $colorRule,
            'ldangerbutton'     => $colorRule,
            'ldangerbuttonhover'=> $colorRule,
            'primary'           => $colorRule,
            'primaryhover'      => $colorRule,
            'lprimary'          => $colorRule,
            'lprimaryhover'     => $colorRule,
            'input'             => $colorRule,
            'linput'            => $colorRule,
            'borderradius'      => $radiusRule,
        ]);

        try {
            $existing = DB::table('theme')->first();
            if ($existing) {
                DB::table('theme')->where('id', $existing->id)->update([
                    'textbutton'         => $request->textbutton         ?? $existing->textbutton,
                    'textbuttonhover'    => $request->textbuttonhover    ?? $existing->textbuttonhover,
                    'dangerbutton'       => $request->dangerbutton       ?? $existing->dangerbutton,
                    'dangerbuttonhover'  => $request->dangerbuttonhover  ?? $existing->dangerbuttonhover,
                    'ltextbutton'        => $request->ltextbutton        ?? $existing->ltextbutton,
                    'ltextbuttonhover'   => $request->ltextbuttonhover   ?? $existing->ltextbuttonhover,
                    'ldangerbutton'      => $request->ldangerbutton      ?? $existing->ldangerbutton,
                    'ldangerbuttonhover' => $request->ldangerbuttonhover ?? $existing->ldangerbuttonhover,
                    'primary'            => $request->primary            ?? $existing->primary,
                    'primaryhover'       => $request->primaryhover       ?? $existing->primaryhover,
                    'lprimary'           => $request->lprimary           ?? $existing->lprimary,
                    'lprimaryhover'      => $request->lprimaryhover      ?? $existing->lprimaryhover,
                    'borderradius'       => $request->borderradius       ?? $existing->borderradius,
                    'input'              => $request->input              ?? $existing->input,
                    'linput'             => $request->linput             ?? $existing->linput,
                    'updated_at'         => \Carbon\Carbon::now(),
                ]);
            }
        } catch (\Exception $e) {
            $this->alert->danger('Failed to update button settings: ' . $e->getMessage())->flash();
            return redirect()->back();
        }

        $this->alert->success('Button settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
