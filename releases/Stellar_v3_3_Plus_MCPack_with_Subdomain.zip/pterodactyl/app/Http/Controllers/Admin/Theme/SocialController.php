<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class SocialController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        try {
            $theme = DB::table('theme')->first();
        } catch (\Exception $e) {
            $theme = null;
        }

        return view('admin.theme.social', ['theme' => $theme]);
    }

    public function update(Request $request)
    {
        $request->validate([
            'website'       => 'nullable|string|max:500',
            'discord'       => 'nullable|string|max:500',
            'status'        => 'nullable|string|max:500',
            'knowledgebase' => 'nullable|string|max:500',
            'billing'       => 'nullable|string|max:500',
        ]);

        try {
            $existing = DB::table('theme')->first();
            if ($existing) {
                DB::table('theme')->where('id', $existing->id)->update([
                    'website'       => $request->website       ?? 'none',
                    'discord'       => $request->discord       ?? 'none',
                    'status'        => $request->status        ?? 'none',
                    'knowledgebase' => $request->knowledgebase ?? 'none',
                    'billing'       => $request->billing       ?? 'none',
                    'updated_at'    => \Carbon\Carbon::now(),
                ]);
            }
        } catch (\Exception $e) {
            $this->alert->danger('Failed to update social settings: ' . $e->getMessage())->flash();
            return redirect()->back();
        }

        $this->alert->success('Social settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
