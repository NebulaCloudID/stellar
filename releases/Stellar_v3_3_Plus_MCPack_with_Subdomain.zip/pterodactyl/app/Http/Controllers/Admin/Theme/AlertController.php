<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class AlertController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        try {
            $theme = DB::table('theme')->first();
        } catch (\Exception $e) {
            $theme = null;
        }

        return view('admin.theme.alert', ['theme' => $theme]);
    }

    public function update(Request $request)
    {
        $request->validate([
            'typealert'        => 'required|in:disabled,info,warning,error,success',
            'alertdescription' => 'nullable|string|max:1000',
        ]);

        try {
            $existing = DB::table('theme')->first();
            if ($existing) {
                DB::table('theme')->where('id', $existing->id)->update([
                    'typealert'        => $request->typealert,
                    'alertdescription' => $request->alertdescription ?? 'none',
                    'updated_at'       => \Carbon\Carbon::now(),
                ]);
            }
        } catch (\Exception $e) {
            $this->alert->danger('Failed to update alert settings: ' . $e->getMessage())->flash();
            return redirect()->back();
        }

        $this->alert->success('Alert settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
