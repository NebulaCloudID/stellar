<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class MetaController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        try {
            $theme = DB::table('theme')->first();
        } catch (\Exception $e) {
            $theme = null;
        }

        return view('admin.theme.meta', ['theme' => $theme]);
    }

    public function update(Request $request)
    {
        $request->validate([
            'discription' => 'nullable|string|max:500',
            'title'       => 'nullable|string|max:255',
            'metacolor'   => 'nullable|regex:/^#[0-9A-Fa-f]{3,8}$/',
        ]);

        try {
            $existing = DB::table('theme')->first();
            if ($existing) {
                DB::table('theme')->where('id', $existing->id)->update([
                    'discription' => $request->discription ?? $existing->discription,
                    'title'       => $request->title       ?? $existing->title,
                    'metacolor'   => $request->metacolor   ?? $existing->metacolor,
                    'updated_at'  => \Carbon\Carbon::now(),
                ]);
            }
        } catch (\Exception $e) {
            $this->alert->danger('Failed to update meta settings: ' . $e->getMessage())->flash();
            return redirect()->back();
        }

        $this->alert->success('Meta settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
