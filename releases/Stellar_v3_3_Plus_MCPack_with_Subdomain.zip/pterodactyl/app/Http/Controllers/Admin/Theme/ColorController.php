<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class ColorController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->alert = $alert;
    }

    public function index()
    {
        try {
            $theme = DB::table('theme')->first();
        } catch (\Exception $e) {
            $theme = null;
        }

        return view('admin.theme.color', ['theme' => $theme]);
    }

    public function update(Request $request)
    {
        $colorRule = 'nullable|regex:/^#[0-9A-Fa-f]{3,8}$/';

        $request->validate([
            'highlightcolor'  => $colorRule,
            'lightcolor'      => $colorRule,
            'color'           => $colorRule,
            'subcolor'        => $colorRule,
            'color4'          => $colorRule,
            'color5'          => $colorRule,
            'color6'          => $colorRule,
            'dark'            => $colorRule,
            'primary'         => $colorRule,
            'primaryhover'    => $colorRule,
            'secondary'       => $colorRule,
            'secondaryhover'  => $colorRule,
            'background'      => $colorRule,
            'lhighlightcolor' => $colorRule,
            'llightcolor'     => $colorRule,
            'lcolor'          => $colorRule,
            'lsubcolor'       => $colorRule,
            'lcolor4'         => $colorRule,
            'lcolor5'         => $colorRule,
            'lcolor6'         => $colorRule,
            'ldark'           => $colorRule,
            'lprimary'        => $colorRule,
            'lprimaryhover'   => $colorRule,
            'lsecondary'      => $colorRule,
            'lsecondaryhover' => $colorRule,
            'lbackground'     => $colorRule,
        ]);

        try {
            $existing = DB::table('theme')->first();
            if ($existing) {
                DB::table('theme')->where('id', $existing->id)->update([
                    'highlightcolor'  => $request->highlightcolor  ?? $existing->highlightcolor,
                    'lightcolor'      => $request->lightcolor      ?? $existing->lightcolor,
                    'color'           => $request->color           ?? $existing->color,
                    'subcolor'        => $request->subcolor        ?? $existing->subcolor,
                    'color4'          => $request->color4          ?? $existing->color4,
                    'color5'          => $request->color5          ?? $existing->color5,
                    'color6'          => $request->color6          ?? $existing->color6,
                    'dark'            => $request->dark            ?? $existing->dark,
                    'primary'         => $request->primary         ?? $existing->primary,
                    'primaryhover'    => $request->primaryhover    ?? $existing->primaryhover,
                    'secondary'       => $request->secondary       ?? $existing->secondary,
                    'secondaryhover'  => $request->secondaryhover  ?? $existing->secondaryhover,
                    'background'      => $request->background      ?? $existing->background,
                    'lhighlightcolor' => $request->lhighlightcolor ?? $existing->lhighlightcolor,
                    'llightcolor'     => $request->llightcolor     ?? $existing->llightcolor,
                    'lcolor'          => $request->lcolor          ?? $existing->lcolor,
                    'lsubcolor'       => $request->lsubcolor       ?? $existing->lsubcolor,
                    'lcolor4'         => $request->lcolor4         ?? $existing->lcolor4,
                    'lcolor5'         => $request->lcolor5         ?? $existing->lcolor5,
                    'lcolor6'         => $request->lcolor6         ?? $existing->lcolor6,
                    'ldark'           => $request->ldark           ?? $existing->ldark,
                    'lprimary'        => $request->lprimary        ?? $existing->lprimary,
                    'lprimaryhover'   => $request->lprimaryhover   ?? $existing->lprimaryhover,
                    'lsecondary'      => $request->lsecondary      ?? $existing->lsecondary,
                    'lsecondaryhover' => $request->lsecondaryhover ?? $existing->lsecondaryhover,
                    'lbackground'     => $request->lbackground     ?? $existing->lbackground,
                    'updated_at'      => \Carbon\Carbon::now(),
                ]);
            }
        } catch (\Exception $e) {
            $this->alert->danger('Failed to update color settings: ' . $e->getMessage())->flash();
            return redirect()->back();
        }

        $this->alert->success('Color settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
