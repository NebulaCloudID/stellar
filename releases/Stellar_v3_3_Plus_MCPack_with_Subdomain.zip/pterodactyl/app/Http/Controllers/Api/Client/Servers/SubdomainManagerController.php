<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Classes\Cloudflare\Auth\APIKey;
use Pterodactyl\Classes\Cloudflare\Endpoints\DNS;
use Pterodactyl\Classes\Cloudflare\Adapter\Guzzle;
use Pterodactyl\Classes\Cloudflare\Endpoints\Zones;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Pterodactyl\Http\Requests\Api\Client\Servers\SubdomainRequest;
use Illuminate\Support\Facades\Log;

class SubdomainManagerController extends ClientApiController
{
    private $settingsRepository;

    public function __construct(SettingsRepositoryInterface $settingsRepository)
    {
        parent::__construct();
        $this->settingsRepository = $settingsRepository;
    }

    public function index(SubdomainRequest $request, Server $server): array
    {
        $domains = DB::table('subdomain_manager_domains')->get();
        $subdomains = DB::table('subdomain_manager_subdomains')->where('server_id', $server->id)->get();
        $allocation = DB::table('allocations')->where('id', '=', $server->allocation_id)->get();

        $filteredDomains = $domains->filter(function($domain) use ($server) {
            return in_array($server->egg_id, explode(',', $domain->egg_ids));
        });

        $subdomains->each(function($subdomain) use ($filteredDomains) {
            $subdomain->domain = optional($filteredDomains->firstWhere('id', $subdomain->domain_id))->domain;
        });

        return [
            'success' => true,
            'data' => [
                'domains' => $filteredDomains->toArray(),
                'subdomains' => $subdomains,
                'ipAlias' => $allocation[0]->ip,
            ],
        ];
    }

    public function create(SubdomainRequest $request, Server $server): array
    {
        $request->validate([
            'subdomain' => 'required|min:2|max:32|regex:/^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?$/',
            'domainId' => 'required|integer'
        ]);

        $subdomain = strtolower(trim(strip_tags($request->input('subdomain'))));
        $domain = DB::table('subdomain_manager_domains')->find($request->input('domainId'));

        if (!$domain) {
            throw new DisplayException('Domain not found.');
        }

        $protocol = unserialize($domain->protocol)[$server->egg_id] ?? null;
        $type = unserialize($domain->protocol_types)[$server->egg_id] ?? 'tcp';

        $existingSubdomains = DB::table('subdomain_manager_subdomains')
            ->where('server_id', $server->id)
            ->count();

        $maxSubdomains = $this->settingsRepository->get('settings::subdomain::max_subdomain', 1);

        if ($existingSubdomains >= $maxSubdomains) {
            throw new DisplayException("You can create a maximum of $maxSubdomains subdomains.");
        }

        $subdomainExists = DB::table('subdomain_manager_subdomains')
            ->where('domain_id', $domain->id)
            ->where('subdomain', $subdomain)
            ->exists();

        if ($subdomainExists) {
            throw new DisplayException("This subdomain is already taken: $subdomain");
        }

        $allocation = DB::table('allocations')->where('id', '=', $server->allocation_id)->get();
        if (count($allocation) < 1) {
            throw new DisplayException('Allocation not found.');
        }

        $alias = $allocation[0]->ip_alias ?? $allocation[0]->ip;

        try {
            $zoneID = $this->getCloudflareZoneID($domain->domain);

            if ($allocation[0]->ip_alias) {
                $this->createCloudflareSRVRecord($zoneID, $subdomain, $domain->domain, $allocation[0]->ip_alias, $protocol, $type, $allocation[0]->port);
            } else {
                $this->createCloudflareRecords($zoneID, $subdomain, $domain->domain, $allocation[0]->ip, $protocol, $type, $allocation[0]->port);
            }

            DB::table('subdomain_manager_subdomains')->insert([
                'server_id' => $server->id,
                'domain_id' => $domain->id,
                'subdomain' => $subdomain,
                'ip' => $allocation[0]->ip,
                'port' => $allocation[0]->port,
                'record_type' => $protocol ? 'SRV' : 'A'
            ]);

            Log::info('Subdomain created', [
                'server_id' => $server->id,
                'subdomain' => "$subdomain.{$domain->domain}",
                'ip' => $allocation[0]->ip,
                'port' => $allocation[0]->port,
                'user' => $request->user()->email ?? 'unknown',
            ]);

            return ['success' => true];
        } catch (\Exception $e) {
            throw new DisplayException('Failed to create subdomain.');
        }
    }

    public function delete(SubdomainRequest $request, Server $server, $id): array
    {
        $subdomain = DB::table('subdomain_manager_subdomains')
            ->where('id', $id)
            ->where('server_id', $server->id)
            ->first();

        if (!$subdomain) {
            throw new DisplayException('Subdomain not found.');
        }

        $domain = DB::table('subdomain_manager_domains')->find($subdomain->domain_id);

        if (!$domain) {
            throw new DisplayException('Domain not found.');
        }

        $protocol = unserialize($domain->protocol)[$server->egg_id] ?? null;
        $type = unserialize($domain->protocol_types)[$server->egg_id] ?? 'tcp';

        try {
            $zoneID = $this->getCloudflareZoneID($domain->domain);

            // Try to delete both A and SRV records
            $this->deleteCloudflareARecord($zoneID, $subdomain->subdomain, $domain->domain);
            $this->deleteCloudflareSRVRecord($zoneID, $subdomain->subdomain, $domain->domain, $protocol, $type);

            DB::table('subdomain_manager_subdomains')->where('id', $id)->delete();

            Log::info('Subdomain deleted', [
                'server_id' => $server->id,
                'subdomain' => "{$subdomain->subdomain}.{$domain->domain}",
                'user' => $request->user()->email ?? 'unknown',
            ]);

            return ['success' => true];
        } catch (\Exception $e) {
            throw new DisplayException('Failed to delete subdomain.');
        }
    }

    public function updateAllocation(Request $request, Server $server): array
    {
        $request->validate([
            'new_ip' => 'required|ip',
            'new_port' => 'required|integer'
        ]);

        $new_ip = $request->input('new_ip');
        $new_port = $request->input('new_port');

        $subdomains = DB::table('subdomain_manager_subdomains')
            ->where('server_id', $server->id)
            ->get();

        if ($subdomains->isEmpty()) {
            return ['success' => false, 'message' => 'No subdomains found for this server.'];
        }

        $allocation = DB::table('allocations')->where('id', '=', $server->allocation_id)->get();
        if (count($allocation) < 1) {
            return ['success' => false, 'message' => 'Allocation not found.'];
        }

        DB::table('allocations')->where('id', $server->allocation_id)->update([
            'ip' => $new_ip,
            'port' => $new_port,
        ]);

        try {
            foreach ($subdomains as $subdomain) {
                $domain = DB::table('subdomain_manager_domains')->find($subdomain->domain_id);
                if (!$domain) {
                    return ['success' => false, 'message' => 'Domain not found.'];
                }

                $protocol = unserialize($domain->protocol)[$server->egg_id] ?? null;
                $type = unserialize($domain->protocol_types)[$server->egg_id] ?? 'tcp';

                $zoneID = $this->getCloudflareZoneID($domain->domain);

                try {
                    // Try to update the A record with the new IP
                    $this->updateCloudflareARecord($zoneID, $subdomain->subdomain, $domain->domain, $new_ip);
                } catch (\Exception $e) {
                    Log::info('Record A not found, only SRV record will be updated', ['subdomain' => $subdomain->subdomain, 'domain' => $domain->domain]);
                }

                // Update the SRV record with the new port
                $this->updateCloudflareSRVRecord($zoneID, $subdomain->subdomain, $domain->domain, $protocol, $type, $new_port);

                DB::table('subdomain_manager_subdomains')->where('id', $subdomain->id)->update([
                    'ip' => $new_ip,
                    'port' => $new_port,
                ]);
            }

            return ['success' => true, 'message' => 'Allocation updated successfully.'];
        } catch (\Exception $e) {
            return ['success' => false, 'message' => 'Failed to update allocation.'];
        }
    }

    public function getMaxSubdomains(SubdomainRequest $request, Server $server): array
    {
        $maxSubdomains = $this->settingsRepository->get('settings::subdomain::max_subdomain', 1);
        return [
            'success' => true,
            'max_subdomains' => $maxSubdomains,
        ];
    }

    private function getCloudflareZoneID($domain)
    {
        $key = new APIKey(
            $this->settingsRepository->get('settings::subdomain::cf_email', ''),
            $this->settingsRepository->get('settings::subdomain::cf_api_key', '')
        );

        $adapter = new Guzzle($key);
        $zones = new Zones($adapter);

        return $zones->getZoneID($domain);
    }

    private function createCloudflareRecords($zoneID, $subdomain, $domain, $ip, $protocol, $type, $port)
    {
        $adapter = new Guzzle(new APIKey(
            $this->settingsRepository->get('settings::subdomain::cf_email', ''),
            $this->settingsRepository->get('settings::subdomain::cf_api_key', '')
        ));

        $dns = new DNS($adapter);

        $dns->addRecord($zoneID, [
            'type' => 'A',
            'name' => $subdomain,
            'content' => $ip,
            'proxiable' => false,
            'proxied' => false,
            'ttl' => 120
        ]);

        if ($protocol) {
            $dns->addRecord($zoneID, [
                'type' => 'SRV',
                'data' => [
                    'name' => $subdomain,
                    'ttl' => 120,
                    'service' => $protocol,
                    'proto' => "_$type",
                    'weight' => 1,
                    'port' => $port,
                    'priority' => 1,
                    'target' => "$subdomain.$domain",
                ]
            ]);
        }
    }

    private function createCloudflareSRVRecord($zoneID, $subdomain, $domain, $alias, $protocol, $type, $port)
    {
        $adapter = new Guzzle(new APIKey(
            $this->settingsRepository->get('settings::subdomain::cf_email', ''),
            $this->settingsRepository->get('settings::subdomain::cf_api_key', '')
        ));

        $dns = new DNS($adapter);

        $dns->addRecord($zoneID, [
            'type' => 'SRV',
            'data' => [
                'name' => $subdomain,
                'ttl' => 120,
                'service' => $protocol,
                'proto' => "_$type",
                'weight' => 1,
                'port' => $port,
                'priority' => 1,
                'target' => $alias,
            ]
        ]);
    }

    private function updateCloudflareARecord($zoneID, $subdomain, $domain, $new_ip)
    {
        $adapter = new Guzzle(new APIKey(
            $this->settingsRepository->get('settings::subdomain::cf_email', ''),
            $this->settingsRepository->get('settings::subdomain::cf_api_key', '')
        ));

        $dns = new DNS($adapter);
        $records = $dns->listRecords($zoneID, 'A', "$subdomain.$domain");

        if (count($records->result) > 0) {
            $dns->deleteRecord($zoneID, $records->result[0]->id);
            $dns->addRecord($zoneID, [
                'type' => 'A',
                'name' => $subdomain,
                'content' => $new_ip,
                'proxiable' => false,
                'proxied' => false,
                'ttl' => 120
            ]);
        } else {
            throw new \Exception('Record A not found');
        }
    }

    private function updateCloudflareSRVRecord($zoneID, $subdomain, $domain, $protocol, $type, $new_port)
    {
        $adapter = new Guzzle(new APIKey(
            $this->settingsRepository->get('settings::subdomain::cf_email', ''),
            $this->settingsRepository->get('settings::subdomain::cf_api_key', '')
        ));

        $dns = new DNS($adapter);
        $records = $dns->listRecords($zoneID, 'SRV', "$protocol._$type.$subdomain.$domain");

        if (count($records->result) > 0) {
            $dns->deleteRecord($zoneID, $records->result[0]->id);
            $dns->addRecord($zoneID, [
                'type' => 'SRV',
                'data' => [
                    'name' => $subdomain,
                    'ttl' => 120,
                    'service' => $protocol,
                    'proto' => "_$type",
                    'weight' => 1,
                    'port' => $new_port,
                    'priority' => 1,
                    'target' => "$subdomain.$domain",
                ]
            ]);
        } else {
            throw new \Exception('SRV record not found');
        }
    }

    private function deleteCloudflareARecord($zoneID, $subdomain, $domain)
    {
        $adapter = new Guzzle(new APIKey(
            $this->settingsRepository->get('settings::subdomain::cf_email', ''),
            $this->settingsRepository->get('settings::subdomain::cf_api_key', '')
        ));

        $dns = new DNS($adapter);
        $records = $dns->listRecords($zoneID, 'A', "$subdomain.$domain");

        if (count($records->result) > 0) {
            return $dns->deleteRecord($zoneID, $records->result[0]->id);
        }

        return true;
    }

    private function deleteCloudflareSRVRecord($zoneID, $subdomain, $domain, $protocol, $type)
    {
        $adapter = new Guzzle(new APIKey(
            $this->settingsRepository->get('settings::subdomain::cf_email', ''),
            $this->settingsRepository->get('settings::subdomain::cf_api_key', '')
        ));

        $dns = new DNS($adapter);
        $records = $dns->listRecords($zoneID, 'SRV', "$protocol._$type.$subdomain.$domain");

        if (count($records->result) > 0) {
            return $dns->deleteRecord($zoneID, $records->result[0]->id);
        }

        return true;
    }

    private function deleteCloudflareRecords($zoneID, $subdomain, $domain, $protocol, $type)
    {
        $this->deleteCloudflareARecord($zoneID, $subdomain, $domain);
        $this->deleteCloudflareSRVRecord($zoneID, $subdomain, $domain, $protocol, $type);
    }
}
