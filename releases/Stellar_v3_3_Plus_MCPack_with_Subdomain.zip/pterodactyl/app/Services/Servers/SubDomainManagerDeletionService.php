<?php

namespace Pterodactyl\Services\Servers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Classes\Cloudflare\Auth\APIKey;
use Pterodactyl\Classes\Cloudflare\Adapter\Guzzle;
use Pterodactyl\Classes\Cloudflare\Endpoints\DNS;
use Pterodactyl\Classes\Cloudflare\Endpoints\Zones;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class SubDomainManagerDeletionService
{
    private $settingsRepository;

    public function __construct(SettingsRepositoryInterface $settingsRepository)
    {
        $this->settingsRepository = $settingsRepository;
    }

    /**
     * Delete all subdomains and their Cloudflare DNS records when a server is deleted.
     *
     * @param int $serverId
     * @param int $eggId
     */
    public function delete(int $serverId, int $eggId): void
    {
        $subdomains = DB::table('subdomain_manager_subdomains')
            ->where('server_id', $serverId)
            ->get();

        if ($subdomains->isEmpty()) {
            return;
        }

        foreach ($subdomains as $subdomain) {
            $domain = DB::table('subdomain_manager_domains')->find($subdomain->domain_id);

            if (!$domain) {
                Log::warning('SubDomainManagerDeletionService: Domain not found for subdomain', [
                    'subdomain_id' => $subdomain->id,
                    'domain_id'    => $subdomain->domain_id,
                ]);
                continue;
            }

            $protocol = unserialize($domain->protocol)[$eggId] ?? null;
            $type     = unserialize($domain->protocol_types)[$eggId] ?? 'tcp';

            try {
                $zoneID = $this->getCloudflareZoneID($domain->domain);
                $this->deleteCloudflareARecord($zoneID, $subdomain->subdomain, $domain->domain);
                $this->deleteCloudflareSRVRecord($zoneID, $subdomain->subdomain, $domain->domain, $protocol, $type);

                Log::info('SubDomainManagerDeletionService: DNS records deleted', [
                    'server_id' => $serverId,
                    'subdomain' => "{$subdomain->subdomain}.{$domain->domain}",
                ]);
            } catch (\Exception $e) {
                Log::error('SubDomainManagerDeletionService: Failed to delete DNS records', [
                    'server_id' => $serverId,
                    'subdomain' => $subdomain->subdomain,
                    'domain'    => $domain->domain,
                    'error'     => $e->getMessage(),
                ]);
            }
        }

        // Remove all subdomain DB records for this server
        DB::table('subdomain_manager_subdomains')
            ->where('server_id', $serverId)
            ->delete();

        Log::info('SubDomainManagerDeletionService: All subdomains removed for server', [
            'server_id' => $serverId,
        ]);
    }

    private function getCloudflareZoneID(string $domain): string
    {
        $key     = new APIKey(
            $this->settingsRepository->get('settings::subdomain::cf_email', ''),
            $this->settingsRepository->get('settings::subdomain::cf_api_key', '')
        );
        $adapter = new Guzzle($key);
        $zones   = new Zones($adapter);

        return $zones->getZoneID($domain);
    }

    private function deleteCloudflareARecord(string $zoneID, string $subdomain, string $domain): void
    {
        $dns     = new DNS(new Guzzle(new APIKey(
            $this->settingsRepository->get('settings::subdomain::cf_email', ''),
            $this->settingsRepository->get('settings::subdomain::cf_api_key', '')
        )));
        $records = $dns->listRecords($zoneID, 'A', "$subdomain.$domain");

        if (count($records->result) > 0) {
            $dns->deleteRecord($zoneID, $records->result[0]->id);
        }
    }

    private function deleteCloudflareSRVRecord(string $zoneID, string $subdomain, string $domain, ?string $protocol, string $type): void
    {
        if (!$protocol) {
            return;
        }

        $dns     = new DNS(new Guzzle(new APIKey(
            $this->settingsRepository->get('settings::subdomain::cf_email', ''),
            $this->settingsRepository->get('settings::subdomain::cf_api_key', '')
        )));
        $records = $dns->listRecords($zoneID, 'SRV', "$protocol._$type.$subdomain.$domain");

        if (count($records->result) > 0) {
            $dns->deleteRecord($zoneID, $records->result[0]->id);
        }
    }
}
