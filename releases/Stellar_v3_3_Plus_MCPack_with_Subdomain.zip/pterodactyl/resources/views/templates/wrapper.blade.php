<html>
    <head>
        <title>{{ config('app.name', 'Pterodactyl') }}</title>

        @section('meta')
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <meta name="robots" content="noindex">

            <?php
            try {
                $settings = \Illuminate\Support\Facades\DB::table('theme')->first();
            } catch (\Exception $e) {
                $settings = null;
            }
            ?>

            @if(!is_null($settings))
            <meta property="og:type" content="website" />
            <meta property="og:image" content="<?php echo e($settings->logo ?? ''); ?>"/>
            <meta property="og:description" content="<?php echo e($settings->discription ?? ''); ?>" />
            <meta name="theme-color" content="<?php echo e($settings->metacolor ?? '#0e4688'); ?>">
            <meta property="twitter:title" content="<?php echo e($settings->title ?? config('app.name')); ?>">

            <link rel="icon" type="image/png" href="<?php echo e($settings->logo ?? '/favicons/favicon-32x32.png'); ?>" sizes="16x16">
            <link rel="shortcut icon" href="<?php echo e($settings->logo ?? '/favicons/favicon-32x32.png'); ?>">

            <style>
                body{
                    <?php if (!empty($settings->backgroundimage) && $settings->backgroundimage !== 'none'): ?>
                    background-image:url("<?php echo e($settings->backgroundimage); ?>");
                    background-repeat:no-repeat;
                    background-size:cover;
                    background-position:center;
                    background-attachment: fixed;
                    <?php endif; ?>
                }
                :root{
                    --highlight-color:<?php echo e($settings->highlightcolor); ?>;
                    --light-color:<?php echo e($settings->lightcolor); ?>;
                    --color:<?php echo e($settings->color); ?>;
                    --sub-color:<?php echo e($settings->subcolor); ?>;
                    --color-4:<?php echo e($settings->color4); ?>;
                    --color-5:<?php echo e($settings->color5); ?>;
                    --color-6:<?php echo e($settings->color6); ?>;
                    --dark:<?php echo e($settings->dark); ?>;
                    --background-color:<?php echo e($settings->background); ?>;
                    --input:<?php echo e($settings->input); ?>;
                    --primary:<?php echo e($settings->primary); ?>;
                    --secondary:<?php echo e($settings->secondary); ?>;
                    --primary-hover:<?php echo e($settings->primaryhover); ?>;
                    --secondary-hover:<?php echo e($settings->secondaryhover); ?>;
                    --danger:<?php echo e($settings->dangerbutton ?? '#DC2626'); ?>;
                    --danger-hover:<?php echo e($settings->dangerbuttonhover ?? '#ff4040'); ?>;
                    --text:<?php echo e($settings->textbutton ?? '#4E5C7E'); ?>;
                    --text-hover:<?php echo e($settings->textbuttonhover ?? '#60709A'); ?>;

                    --black:#000000;
                    --white:#fff;

                    --borderradius:<?php echo e($settings->borderradius ?? '7'); ?>px;

                    <?php if (empty($settings->sidegraph)) {echo "--sidegraph:none;";}?>
                    <?php if (empty($settings->subnavigation)) {echo "--subnavigation:none;";}?>
                    <?php if (empty($settings->infoelement)) {echo "--infoelement:none;";}?>
                    <?php if (empty($settings->graphcard)) {echo "--graphcard:none;";}?>

                    <?php if (($settings->website ?? 'none') === 'none') {echo "--website:none;";} else {echo "--website:flex;";}?>
                    <?php if (($settings->status ?? 'none') === 'none') {echo "--status:none;";} else {echo "--status:flex;";}?>
                    <?php if (($settings->billing ?? 'none') === 'none') {echo "--billing:none;";} else {echo "--billing:flex;";}?>
                    <?php if (($settings->discord ?? 'none') === 'none') {echo "--discord:none;";} else {echo "--discord:flex;";}?>
                    <?php if (($settings->knowledgebase ?? 'none') === 'none') {echo "--knowledgebase:none;";} else {echo "--knowledgebase:flex;";}?>
                }

                .darkmode{
                    --highlight-color:<?php echo e($settings->lhighlightcolor); ?>;
                    --light-color:<?php echo e($settings->llightcolor); ?>;
                    --color:<?php echo e($settings->lcolor); ?>;
                    --sub-color:<?php echo e($settings->lsubcolor); ?>;
                    --color-4:<?php echo e($settings->lcolor4); ?>;
                    --color-5:<?php echo e($settings->lcolor5); ?>;
                    --color-6:<?php echo e($settings->lcolor6); ?>;
                    --dark:<?php echo e($settings->ldark); ?>;
                    --background-color:<?php echo e($settings->lbackground); ?>;
                    --input:<?php echo e($settings->linput); ?>;
                    --primary:<?php echo e($settings->lprimary); ?>;
                    --secondary:<?php echo e($settings->lsecondary); ?>;
                    --primary-hover:<?php echo e($settings->lprimaryhover); ?>;
                    --secondary-hover:<?php echo e($settings->lsecondaryhover); ?>;
                    --danger:<?php echo e($settings->ldangerbutton ?? '#FF4747'); ?>;
                    --danger-hover:<?php echo e($settings->ldangerbuttonhover ?? '#FF5C5C'); ?>;
                    --text:<?php echo e($settings->ltextbutton ?? '#E0EFFF'); ?>;
                    --text-hover:<?php echo e($settings->ltextbuttonhover ?? '#EBF4FF'); ?>;

                    --black:#fff;
                    --white:#000000;
                }
            </style>
            @endif

            <link rel="manifest" href="/favicons/manifest.json">
            <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
            <meta name="msapplication-config" content="/favicons/browserconfig.xml">
            <meta name="theme-color" content="#0e4688">

        @show

        @section('user-data')
            @if(!is_null(Auth::user()))
                <script>
                    window.PterodactylUser = {!! json_encode(Auth::user()->toVueObject()) !!};
                </script>
            @endif
            @if(!empty($siteConfiguration))
                <script>
                    window.SiteConfiguration = {!! json_encode($siteConfiguration) !!};
                </script>
            @endif
        @show
        <style>
            @import url('//fonts.googleapis.com/css?family=Rubik:300,400,500&display=swap');
            @import url('//fonts.googleapis.com/css?family=IBM+Plex+Mono|IBM+Plex+Sans:500&display=swap');
        </style>

        @yield('assets')

        @include('layouts.scripts')
    </head>
    <body class="{{ $css['body'] ?? 'bg-neutral-50' }}">
        @section('content')
            @yield('above-container')
            @yield('container')
            @yield('below-container')
        @show
        @section('scripts')
            {!! $asset->js('main.js') !!}
        @show

    {{-- License tracking script removed --}}
    </body>
</html>
