@extends('layouts.admin')

@section('title')
    List Domains
@endsection

@section('content-header')
    <h1>SubDomain Manager<small>You can create, edit, delete domains.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">SubDomain Manager</li>
    </ol>
@endsection

@section('content')
    @if (count($errors) > 0)
        <div class="alert alert-danger" id="flash-alert">
            @foreach ($errors->all() as $error)
                {{ $error }}<br>
            @endforeach
        </div>
    @endif
    @foreach (Alert::getMessages() as $type => $messages)
        @foreach ($messages as $message)
            <div class="alert alert-{{ $type }} alert-dismissible" id="flash-alert" role="alert">
                <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                {!! $message !!}
            </div>
        @endforeach
    @endforeach
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Domain List</h3>
                    <div class="box-tools">
                        <a href="{{ route('admin.subdomain.new') }}"><button type="button" class="btn btn-sm btn-primary" style="border-radius: 0 3px 3px 0;margin-left:-1px;">Create New</button></a>
                    </div>
                </div>
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tbody>
                        <tr>
                            <th>#</th>
                            <th>Domain</th>
                            <th>Actions</th>
                        </tr>
                        @foreach ($domains as $domain)
                            <tr>
                                <td>{{$domain['id']}}</td>
                                <td>{{$domain['domain']}}</td>
                                <td>
                                    <a title="Edit" class="btn btn-xs btn-primary" href="{{ route('admin.subdomain.edit', $domain['id']) }}"><i class="fa fa-pencil"></i></a>
                                    <a title="Delete" class="btn btn-xs btn-danger" data-action="delete-domain" data-id="{{ $domain['id'] }}"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title">SubDomain List</h3>
                </div>
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tbody>
                        <tr>
                            <th>#</th>
                            <th>SubDomain</th>
                            <th>IP</th>
                            <th>Port</th>
                            <th>Type</th>
                            <th>Server</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                        @foreach ($subdomains as $subdomain)
                            <tr id="subdomain-row-{{ $subdomain['id'] }}">
                                <td>{{$subdomain['id']}}</td>
                                <td><strong>{{$subdomain['subdomain']}}</strong>.{{$subdomain['domain']['domain']}}</td>
                                <td><code>{{$subdomain['ip'] ?? '-'}}</code></td>
                                <td><span class="label label-default">{{$subdomain['port']}}</span></td>
                                <td>
                                    @if($subdomain['record_type'] === 'SRV')
                                        <span class="label label-warning">SRV</span>
                                    @else
                                        <span class="label label-info">A</span>
                                    @endif
                                </td>
                                <td>
                                    @if($subdomain['server']->id !== 0)
                                        <a href="{{ route('index') }}/server/{{ $subdomain['server']->uuidShort }}" target="_blank">{{$subdomain['server']->name}}</a>
                                    @else
                                        <span class="text-muted">Not found</span>
                                    @endif
                                </td>
                                <td><small>{{ isset($subdomain['created_at']) ? \Carbon\Carbon::parse($subdomain['created_at'])->diffForHumans() : '-' }}</small></td>
                                <td>
                                    @if($subdomain['server']->id !== 0)
                                        <a title="View Server" class="btn btn-xs btn-primary" href="/server/{{ $subdomain['server']->uuidShort }}" target="_blank"><i class="fa fa-eye"></i></a>
                                    @endif
                                    <a title="Delete Subdomain" class="btn btn-xs btn-danger" data-action="delete-subdomain" data-id="{{ $subdomain['id'] }}" data-name="{{ $subdomain['subdomain'] }}.{{ $subdomain['domain']['domain'] }}"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Settings</h3>
                </div>
                <form method="post" action="{{ route('admin.subdomain.settings')  }}">
                    <div class="box-body">
                        <div class="form-group">
                            <label for="cf_email" class="form-label">CloudFlare Email</label>
                            <input type="text" name="cf_email" id="cf_email" class="form-control" value="{{ $settings['cf_email'] }}" />
                        </div>
                        <div class="form-group">
                            <label for="cf_api_key" class="form-label">CloudFlare Api Key</label>
                            <input type="password" name="cf_api_key" id="cf_api_key" class="form-control" value="{{ $settings['cf_api_key'] }}" />
                        </div>
                        <div class="form-group">
                            <label for="max_subdomain" class="form-label">Max subdomain per server</label>
                            <input type="text" name="max_subdomain" id="max_subdomain" class="form-control" value="{{ $settings['max_subdomain'] }}" />
                        </div>
                    </div>
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        <button type="submit" class="btn btn-success pull-right">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('footer-scripts')
    @parent
    <script>
        // Auto-dismiss flash alerts after 3 seconds
        setTimeout(function () {
            $('#flash-alert').fadeOut('slow');
        }, 3000);

        // Delete Domain
        $('[data-action="delete-domain"]').click(function (event) {
            event.preventDefault();
            let self = $(this);
            swal({
                title: '',
                type: 'warning',
                text: 'Are you sure you want to delete this domain? All associated subdomains will also be removed.',
                showCancelButton: true,
                confirmButtonText: 'Delete',
                confirmButtonColor: '#d9534f',
                closeOnConfirm: false,
                showLoaderOnConfirm: true,
                cancelButtonText: 'Cancel',
            }, function () {
                $.ajax({
                    method: 'DELETE',
                    url: '/admin/subdomain/delete',
                    headers: {'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')},
                    data: {
                        id: self.data('id')
                    }
                }).done((data) => {
                    if (data.success === true) {
                        swal({
                            type: 'success',
                            title: 'Success!',
                            text: 'Domain deleted successfully.'
                        });
                        self.closest('tr').slideUp();
                    } else {
                        swal({
                            type: 'error',
                            title: 'Ooops!',
                            text: (typeof data.error !== 'undefined') ? data.error : 'Failed to delete domain. Please try again later.'
                        });
                    }
                }).fail(() => {
                    swal({
                        type: 'error',
                        title: 'Ooops!',
                        text: 'A system error has occurred. Please try again later.'
                    });
                });
            });
        });

        // Delete Subdomain (admin force delete)
        $('[data-action="delete-subdomain"]').click(function (event) {
            event.preventDefault();
            let self = $(this);
            let name = self.data('name');
            swal({
                title: '',
                type: 'warning',
                text: 'Are you sure you want to force delete subdomain "' + name + '"?',
                showCancelButton: true,
                confirmButtonText: 'Delete',
                confirmButtonColor: '#d9534f',
                closeOnConfirm: false,
                showLoaderOnConfirm: true,
                cancelButtonText: 'Cancel',
            }, function () {
                $.ajax({
                    method: 'DELETE',
                    url: '/admin/subdomain/delete-subdomain',
                    headers: {'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')},
                    data: {
                        id: self.data('id')
                    }
                }).done((data) => {
                    if (data.success === true) {
                        swal({
                            type: 'success',
                            title: 'Success!',
                            text: 'Subdomain "' + name + '" deleted successfully.'
                        });
                        $('#subdomain-row-' + self.data('id')).slideUp();
                    } else {
                        swal({
                            type: 'error',
                            title: 'Ooops!',
                            text: (typeof data.error !== 'undefined') ? data.error : 'Failed to delete subdomain. Please try again later.'
                        });
                    }
                }).fail(() => {
                    swal({
                        type: 'error',
                        title: 'Ooops!',
                        text: 'A system error has occurred. Please try again later.'
                    });
                });
            });
        });
    </script>
@endsection
