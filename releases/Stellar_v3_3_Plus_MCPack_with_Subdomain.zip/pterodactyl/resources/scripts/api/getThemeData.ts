import http from '@/api/http';

export default async (): Promise<Record<string, string>> => {
    try {
        const { data } = await http.get('/api/client/theme');
        return data.data || {};
    } catch (e) {
        return {};
    }
};
