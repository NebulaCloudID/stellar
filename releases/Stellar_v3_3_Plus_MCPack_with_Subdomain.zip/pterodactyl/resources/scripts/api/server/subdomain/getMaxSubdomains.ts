import http from '@/api/http';

export default async (uuid: string): Promise<{ max_subdomains: number }> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/subdomain/max-subdomains`);
    return data;
};
