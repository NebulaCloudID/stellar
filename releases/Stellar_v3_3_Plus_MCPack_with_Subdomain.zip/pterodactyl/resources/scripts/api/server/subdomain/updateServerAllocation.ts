import http from '@/api/http';

interface UpdateAllocationParams {
    new_ip: string;
    new_port: number;
}

export default async (uuid: string, params: UpdateAllocationParams): Promise<{ success: boolean; message: string }> => {
    const { data } = await http.put(`/api/client/servers/${uuid}/subdomain/update-allocation`, params);
    return data;
};
