import { ServerContext } from '@/state/server';
import useSWR from 'swr';
import http from '@/api/http';

export interface Allocation {
    id: number;
    ip: string;
    port: number;
    is_default: boolean;
}

export const getDefaultAllocation = async (uuid: string): Promise<Allocation | null> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/network/allocations`);
    const allocations: Allocation[] = data.data.map((allocation: any) => ({
        id: allocation.attributes.id,
        ip: allocation.attributes.ip,
        port: allocation.attributes.port,
        is_default: allocation.attributes.is_default,
    }));

    return allocations.find(allocation => allocation.is_default) || null;
};
