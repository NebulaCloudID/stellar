import React, { useEffect, useState } from 'react';
import * as Icon from 'react-feather';
import styled from 'styled-components/macro';
import getTheme from '@/api/getThemeData';
import AlertDescription from '@/components/elements/custom/AlertDescription';
import tw from 'twin.macro';

const AlertBox = styled.div`
    ${tw`flex items-center shadow px-4 py-3 mt-4 text-white`}
    border-radius:var(--borderradius);
`;

type AlertType = 'disabled' | 'info' | 'warning' | 'error' | 'success' | null;

const ALERT_STYLES: Record<string, string> = {
    info:    '#589AFC',
    warning: '#FBA101',
    error:   '#DF5438',
    success: '#45AF45',
};

const ALERT_ICONS: Record<string, React.ComponentType<any>> = {
    info:    Icon.Info,
    warning: Icon.AlertCircle,
    error:   Icon.XCircle,
    success: Icon.CheckCircle,
};

export default () => {
    const [alertType, setAlertType] = useState<AlertType>(null);

    useEffect(() => {
        getTheme()
            .then((data) => {
                const type = (data as any)?.typealert ?? 'disabled';
                setAlertType(type as AlertType);
            })
            .catch(() => setAlertType('disabled'));
    }, []);

    // Tidak ditampilkan sama sekali sampai data dimuat, atau jika disabled
    if (!alertType || alertType === 'disabled') return null;

    const bg = ALERT_STYLES[alertType];
    const AlertIcon = ALERT_ICONS[alertType];

    if (!bg || !AlertIcon) return null;

    return (
        <AlertBox css={`background-color: ${bg};`}>
            <AlertIcon css={tw`mr-2`} />
            <AlertDescription />
        </AlertBox>
    );
};
