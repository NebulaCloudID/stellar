import React, { useEffect, useState } from 'react';
import useSWR from 'swr';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faNetworkWired, faPlus, faTrash, faSync } from '@fortawesome/free-solid-svg-icons';
import styled from 'styled-components/macro';
import tw from 'twin.macro';
import { Formik, Form, Field as FormikField, FormikHelpers } from 'formik';
import * as Yup from 'yup';

import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { ServerContext } from '@/state/server';
import useFlash from '@/plugins/useFlash';
import FlashMessageRender from '@/components/FlashMessageRender';
import getServerSubdomains from '@/api/server/subdomain/getServerSubdomains';
import getMaxSubdomains from '@/api/server/subdomain/getMaxSubdomains';
import { getDefaultAllocation, Allocation } from '@/api/server/subdomain/getServerAllocations';
import Spinner from '@/components/elements/Spinner';
import Field from '@/components/elements/Field';
import Button from '@/components/elements/Button';
import FormikFieldWrapper from '@/components/elements/FormikFieldWrapper';
import Select from '@/components/elements/Select';
import Label from '@/components/elements/Label';
import ConfirmationModal from '@/components/elements/ConfirmationModal';
import createServerSubdomain from '@/api/server/subdomain/createServerSubdomain';
import deleteServerSubdomain from '@/api/server/subdomain/deleteServerSubdomain';
import updateServerAllocation from '@/api/server/subdomain/updateServerAllocation';
import { Actions, useStoreActions } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import { httpErrorToHuman } from '@/api/http';
import Modal from '@/components/elements/Modal';

const CustomCode = styled.code`
    ${tw`font-mono py-1 px-2 bg-gray-700 text-white rounded text-sm inline-block`}
`;

const CustomStyledContainer = styled.div`
    ${tw`p-4 bg-gray-800 text-white rounded-lg w-full`}
`;

const TitleSection = styled.div`
    ${tw`flex flex-col md:flex-row justify-between items-start md:items-center mb-4 w-full`}
`;

const TitleText = styled.h1`
    ${tw`text-lg flex items-center`}
`;

const HelpText = styled.p`
    ${tw`text-sm mt-2 md:mt-0`}
`;

const Header = styled.div`
    ${tw`flex justify-between items-center mb-4 w-full`}
`;

const SubdomainTable = styled.table`
    ${tw`w-full bg-gray-900 rounded-lg`}
    th, td {
        ${tw`p-4 text-left align-middle`}
    }
    th {
        ${tw`bg-gray-900`}
    }
    tbody tr:nth-child(odd) {
        ${tw`bg-gray-600`}
    }
`;

const ModalHeader = styled.div`
    ${tw`flex justify-between items-center mb-4`}
`;

export interface SubdomainResponse {
    subdomains: any[],
    domains: any[],
    ipAlias: string,
    canCreateSubdomains: boolean,
}

interface CreateValues {
    subdomain: string,
    domainId: number,
}

const SubdomainContainer = () => {
    const uuid = ServerContext.useStoreState(state => state.server.data!.uuid);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const { data, error, mutate } = useSWR<SubdomainResponse>([uuid, 'subdomain'], key => getServerSubdomains(key), {
        revalidateOnFocus: false,
    });
    const { data: maxSubdomainsData } = useSWR([uuid, 'max-subdomains'], key => getMaxSubdomains(key));
    const maxSubdomains = maxSubdomainsData?.max_subdomains || 1;
    const [isSubmit, setSubmit] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
    const [deleteModalVisible, setDeleteModalVisible] = useState(false);
    const [subdomainToDelete, setSubdomainToDelete] = useState<number | null>(null);
    const [selectedAllocation, setSelectedAllocation] = useState<{ currentIp: string, currentPort: number, newIp: string, newPort: number } | null>(null);
    const { addError, clearFlashes: clearFlashMessages } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    useEffect(() => {
        if (error) {
            clearAndAddHttpError({ key: 'server:subdomain', error });
        } else {
            clearFlashes('server:subdomain');
        }
    }, [error]);

    const submit = ({ subdomain, domainId }: CreateValues, { setSubmitting }: FormikHelpers<CreateValues>) => {
        clearFlashes('server:subdomain');
        setSubmit(true);

        createServerSubdomain(uuid, subdomain, domainId)
            .then(() => {
                mutate();
                setIsModalOpen(false);
                addError({ key: 'server:subdomain', message: 'Subdomain created successfully!', type: 'success' } as any);
            })
            .catch(error => {
                clearAndAddHttpError({ key: 'server:subdomain', error });
            })
            .finally(() => {
                setSubmitting(false);
                setSubmit(false);
            });
    };

    const handleDelete = () => {
        if (subdomainToDelete === null) return;

        setSubmit(true);
        clearFlashMessages('server:subdomain');

        deleteServerSubdomain(uuid, subdomainToDelete)
            .then(() => {
                mutate();
                setDeleteModalVisible(false);
                setSubdomainToDelete(null);
                addError({ key: 'server:subdomain', message: 'Subdomain deleted successfully!', type: 'success' } as any);
            })
            .catch(error => {
                clearAndAddHttpError({ key: 'server:subdomain', error });
                setDeleteModalVisible(false);
                setSubdomainToDelete(null);
            })
            .finally(() => {
                setSubmit(false);
            });
    };

    const handleAllocationUpdate = async () => {
        if (!selectedAllocation) return;

        setSubmit(true);
        try {
            const response = await updateServerAllocation(uuid, { new_ip: selectedAllocation.newIp, new_port: selectedAllocation.newPort });

            if (response.success) {
                mutate();
                addError({ key: 'server:subdomain', message: 'Allocation updated successfully!', type: 'success' } as any);
                setIsUpdateModalOpen(false);
            } else {
                clearAndAddHttpError({ key: 'server:subdomain', error: new Error(response.message) });
            }
        } catch (error) {
            clearAndAddHttpError({ key: 'server:subdomain', error });
        } finally {
            setSubmit(false);
        }
    };

    return (
        <ServerContentBlock title={'Subdomain Management'} css={tw`flex flex-col items-center w-full`}>
            <FlashMessageRender byKey={'server:subdomain'} css={tw`mb-4 w-full`} />
            <Header>
                <TitleSection>
                    <div>
                        <TitleText>Subdomains</TitleText>
                        <HelpText>Create custom subdomains for your server. Each subdomain can be assigned to a specific allocation on your server.</HelpText>
                    </div>
                    {data && (
                        <Button
                            onClick={() => setIsModalOpen(true)}
                            css={tw`flex items-center mt-2 md:mt-0`}
                            disabled={data.subdomains?.length >= maxSubdomains || data.domains.length === 0}
                        >
                            <FontAwesomeIcon icon={faPlus} css={tw`mr-2`} />
                            Create Subdomain
                        </Button>
                    )}
                </TitleSection>
            </Header>
            {!data ? (
                <div css={tw`flex justify-center items-center`}>
                    <Spinner size={'large'} centered />
                </div>
            ) : (
                <>
                    {data.domains?.length > 0 ? (
                        <SubdomainTable>
                            <thead>
                                <tr>
                                    <th>Subdomain</th>
                                    <th>Allocation</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {data.subdomains.length < 1 ? (
                                    <tr>
                                        <td colSpan={3} css={tw`text-center text-sm text-neutral-400 py-4`}>
                                            There are no subdomains for this server.
                                        </td>
                                    </tr>
                                ) : (
                                    data.subdomains.map((item, key) => (
                                        <tr key={key}>
                                            <td>
                                                <div css={tw`flex items-center`}>
                                                    <FontAwesomeIcon icon={faNetworkWired} css={tw`text-gray-400 mr-2`} />
                                                    <CustomCode>{item.subdomain}.{item.domain}{item.record_type === 'CNAME' ? `:${item.port}` : ''}</CustomCode>
                                                </div>
                                            </td>
                                            <td>
                                                <CustomCode>{data.ipAlias}:{item.port}</CustomCode>
                                            </td>
                                            <td>
                                                <Button
                                                    color={'red'}
                                                    size={'xsmall'}
                                                    css={tw`mr-2`}
                                                    onClick={() => { setDeleteModalVisible(true); setSubdomainToDelete(item.id); }}
                                                >
                                                    <FontAwesomeIcon icon={faTrash} />
                                                </Button>
                                                <Button
                                                    color={'green'}
                                                    size={'xsmall'}
                                                    onClick={async () => {
                                                        const defaultAllocation = await getDefaultAllocation(uuid);
                                                        if (!defaultAllocation) {
                                                            clearAndAddHttpError({ key: 'server:subdomain', error: new Error('No default allocation found.') });
                                                            return;
                                                        }
                                                        setIsUpdateModalOpen(true);
                                                        setSelectedAllocation({
                                                            currentIp: data.ipAlias,
                                                            currentPort: item.port,
                                                            newIp: defaultAllocation.ip,
                                                            newPort: defaultAllocation.port,
                                                        });
                                                    }}
                                                >
                                                    <FontAwesomeIcon icon={faSync} />
                                                </Button>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </SubdomainTable>
                    ) : (
                        <p css={tw`text-sm text-neutral-400 text-center py-4`}>
                            There are no available domains for the current server.
                        </p>
                    )}
                </>
            )}

            <Modal visible={isModalOpen} onDismissed={() => setIsModalOpen(false)}>
                <ModalHeader>
                    <h3>Create a New Subdomain</h3>
                </ModalHeader>
                <Formik
                    initialValues={{ subdomain: '', domainId: data?.domains[0]?.id || 0 }}
                    validationSchema={Yup.object().shape({
                        subdomain: Yup.string().min(2).max(32).matches(/^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?$/, 'Only letters, numbers, and hyphens. Cannot start or end with a hyphen.').required('Subdomain is required'),
                    })}
                    onSubmit={submit}
                >
                    {({ isSubmitting }) => (
                        <Form>
                            <Field name={'subdomain'} label={'Subdomain'} />
                            <div>
                                <Label>Domain</Label>
                                <FormikFieldWrapper name={'domainId'}>
                                    <FormikField as={Select} name={'domainId'}>
                                        {data?.domains?.map((item, key) => (
                                            <option key={key} value={item.id}>{item.domain}</option>
                                        ))}
                                    </FormikField>
                                </FormikFieldWrapper>
                            </div>
                            <div css={tw`mt-4 flex justify-end`}>
                                <Button type={'submit'} disabled={isSubmitting || isSubmit} css={tw`mt-4`}>
                                    Create Subdomain
                                </Button>
                            </div>
                        </Form>
                    )}
                </Formik>
            </Modal>

            <Modal visible={isUpdateModalOpen} onDismissed={() => setIsUpdateModalOpen(false)}>
                <ModalHeader>
                    <h3>Update Allocation</h3>
                </ModalHeader>
                {selectedAllocation && (
                    <div>
                        <p>Current Allocation: <CustomCode>{selectedAllocation.currentIp}:{selectedAllocation.currentPort}</CustomCode></p>
                        <p>New Allocation: <CustomCode>{selectedAllocation.newIp}:{selectedAllocation.newPort}</CustomCode></p>
                        <div css={tw`mt-4 flex justify-end`}>
                            <Button
                                size={'small'}
                                color={'green'}
                                onClick={handleAllocationUpdate}
                                disabled={isSubmit}
                            >
                                Confirm Update
                            </Button>
                        </div>
                    </div>
                )}
            </Modal>

            <ConfirmationModal
                visible={deleteModalVisible}
                title={'Delete subdomain?'}
                buttonText={'Yes, delete subdomain'}
                onConfirmed={handleDelete}
                showSpinnerOverlay={isSubmit}
                onModalDismissed={() => setDeleteModalVisible(false)}
            >
                Are you sure you want to delete this subdomain?
            </ConfirmationModal>
        </ServerContentBlock>
    );
};

export default SubdomainContainer;
