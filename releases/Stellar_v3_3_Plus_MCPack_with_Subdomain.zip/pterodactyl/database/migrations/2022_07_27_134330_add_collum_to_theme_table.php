<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddCollumToThemeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Guard: only run if the theme table exists
        if (!Schema::hasTable('theme')) {
            return;
        }

        Schema::table('theme', function (Blueprint $table) {
            if (!Schema::hasColumn('theme', 'metacolor')) {
                $table->string('metacolor')->default('#3B6CDE');
            }
            if (!Schema::hasColumn('theme', 'infoelement')) {
                $table->boolean('infoelement')->default(1);
            }
            if (!Schema::hasColumn('theme', 'newserverlist')) {
                $table->string('newserverlist')->default('table');
            }
            if (!Schema::hasColumn('theme', 'sidegraph')) {
                $table->boolean('sidegraph')->default(1);
            }
            if (!Schema::hasColumn('theme', 'dangerbutton')) {
                $table->string('dangerbutton')->default('#DC2626');
            }
            if (!Schema::hasColumn('theme', 'textbutton')) {
                $table->string('textbutton')->default('#4E5C7E');
            }
            if (!Schema::hasColumn('theme', 'dangerbuttonhover')) {
                $table->string('dangerbuttonhover')->default('#ff4040');
            }
            if (!Schema::hasColumn('theme', 'textbuttonhover')) {
                $table->string('textbuttonhover')->default('#60709A');
            }
            if (!Schema::hasColumn('theme', 'ldangerbutton')) {
                $table->string('ldangerbutton')->default('#FF4747');
            }
            if (!Schema::hasColumn('theme', 'ltextbutton')) {
                $table->string('ltextbutton')->default('#E0EFFF');
            }
            if (!Schema::hasColumn('theme', 'ldangerbuttonhover')) {
                $table->string('ldangerbuttonhover')->default('#FF5C5C');
            }
            if (!Schema::hasColumn('theme', 'ltextbuttonhover')) {
                $table->string('ltextbuttonhover')->default('#EBF4FF');
            }
            if (!Schema::hasColumn('theme', 'longlogo')) {
                $table->string('longlogo')->default('/favicons/favicon-32x32.png');
            }
            if (!Schema::hasColumn('theme', 'borderradius')) {
                $table->string('borderradius')->default('7');
            }
            if (!Schema::hasColumn('theme', 'typealert')) {
                $table->string('typealert')->default('disabled');
            }
            if (!Schema::hasColumn('theme', 'alertdescription')) {
                $table->string('alertdescription')->default('none');
            }
            if (!Schema::hasColumn('theme', 'discord')) {
                $table->string('discord')->default('none');
            }
            if (!Schema::hasColumn('theme', 'website')) {
                $table->string('website')->default('none');
            }
            if (!Schema::hasColumn('theme', 'billing')) {
                $table->string('billing')->default('none');
            }
            if (!Schema::hasColumn('theme', 'knowledgebase')) {
                $table->string('knowledgebase')->default('none');
            }
            if (!Schema::hasColumn('theme', 'status')) {
                $table->string('status')->default('none');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('theme');
    }
}
