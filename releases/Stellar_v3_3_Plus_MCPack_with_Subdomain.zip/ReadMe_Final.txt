Stellar Theme v3.3 + Minecraft Pack Addon v1.2
================================================
Build ini sudah menggabungkan semua file + config CurseForge secara otomatis.

LANGKAH INSTALASI
------------------
1. Salin semua file ke /var/www/pterodactyl/
   (replace file yang ada, JANGAN hapus file yang tidak ada di sini)

2. Jalankan perintah berikut:

   cd /var/www/pterodactyl
   yarn add react-feather
   php artisan migrate
   > yes
   composer dump-autoload
   export NODE_OPTIONS=--openssl-legacy-provider
   yarn build:production
   php artisan cache:clear
   php artisan view:clear
   php artisan config:clear
   php artisan route:clear
   php artisan optimize
   chown -R www-data:www-data /var/www/pterodactyl/*
   chmod -R 755 storage/* bootstrap/cache
   php artisan queue:restart
   systemctl restart pteroq.service

3. Konfigurasi tema di Admin Panel > Settings > Theme

CATATAN
--------
- CurseForge API key sudah tertanam di config/services.php
- Tidak perlu edit .env untuk CurseForge
- Fitur Minecraft hanya muncul di server dengan Nest ID = 1

Support Stellar: https://discord.gg/geCjrRbAwC
Support MCPack:  https://discord.gg/6fqvVGhYXB
