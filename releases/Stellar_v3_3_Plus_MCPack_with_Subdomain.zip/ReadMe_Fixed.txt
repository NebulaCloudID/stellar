Stellar Theme v3.3 — Fixed Build
=================================

FIXES IN THIS BUILD (on top of the v3.3 Updated base)
-------------------------------------------------------

1. wrapper.blade.php
   - FIXED: Fatal crash when theme table doesn't exist yet
     ($settings query now wrapped in try/catch; all output is conditional on $settings not being null)
   - FIXED: Broken `if ():` empty condition that caused a PHP parse error
     (condition now checks backgroundimage is set and not 'none')
   - FIXED: Potential XSS — all $settings values now passed through e() (htmlspecialchars)
   - FIXED: Null-safe access for all $settings properties (uses ?? fallbacks)

2. ClientController.php
   - FIXED: theme() method wrapped in try/catch — panel no longer crashes if theme
     table doesn't exist yet
   - FIXED: theme() return type declared as array (matches actual return)
   - FIXED: Returns empty array for data on error instead of null

3. database/migrations/2021_12_06_134416_create_theme_table.php
   - FIXED: hasTable guard added — migration is safe to re-run
   - FIXED: Duplicate 'graphcard' key in DB::insert array (PHP silently drops the first; now deduplicated)
   - FIXED: Missing 'updated_at' in insert (was causing Carbon\Carbon instead of \Carbon shorthand)
   - FIXED: \Carbon fixed to \Carbon\Carbon (correct fully-qualified class)
   - FIXED: Seed only runs when table is empty (idempotent)

4. database/migrations/2022_07_27_134330_add_collum_to_theme_table.php
   - FIXED: hasTable guard added (skips if theme table doesn't exist)
   - FIXED: hasColumn guard added for every column (safe to re-run without duplicate column errors)

INSTALLATION (same as original)
---------------------------------
1. Copy all files under pterodactyl/ into /var/www/pterodactyl/
   (replace existing files only — do NOT delete anything)

2. Run:
   cd /var/www/pterodactyl
   yarn add react-feather
   php artisan migrate
   > yes
   yarn build:production
   php artisan view:clear
   php artisan cache:clear

3. Configure theme in Admin Panel > Settings > Theme

COMPATIBILITY
--------------
- Pterodactyl 1.11.x: SUPPORTED
- Pterodactyl 1.10.x: SUPPORTED
- Pterodactyl 1.9.x and below: Untested

Support: https://discord.gg/geCjrRbAwC
